##Name: Ritika Munshi
##UID: 118345048
"""
Implementation of k-nearest-neighbor classifier
"""

from numpy import *
from pylab import *
import math
import numpy as np
from binary import *


class KNN(BinaryClassifier):
    """
    This class defines a nearest neighbor classifier, that support
    _both_ K-nearest neighbors _and_ epsilon ball neighbors.
    """

    def __init__(self, opts):
        """
        Initialize the classifier.  There's actually basically nothing
        to do here since nearest neighbors do not really train.
        """

        # remember the options
        self.opts = opts

        # just call reset
        self.reset()

    def reset(self):
        self.trX = zeros((0,0))    # where we will store the training examples
        self.trY = zeros((0))      # where we will store the training labels

    def online(self):
        """
        We're not online
        """
        return False

    def __repr__(self):
        """
        Return a string representation of the tree
        """
        return    "w=" + repr(self.weights)

    def predict(self, X):
        """
        X is a vector that we're supposed to make a prediction about.
        Our return value should be the 'vote' in favor of a positive
        or negative label.  In particular, if, in our neighbor set,
        there are 5 positive training examples and 2 negative
        examples, we return 5-2=3.

        Everything should be in terms of _Euclidean distance_, NOT
        squared Euclidean distance or anything more exotic.
        """

        isKNN = self.opts['isKNN']     # true for KNN, false for epsilon balls
        N     = self.trX.shape[0]      # number of training examples

        if self.trY.size == 0:
            return 0                   # if we haven't trained yet, return 0
        elif isKNN:
            # this is a K nearest neighbor model
            # hint: look at the 'argsort' function in numpy
            K = self.opts['K']         # how many NN to use

            val = 0                    # this is our return value: #pos - #neg of the K nearest neighbors of X
            ### TODO: YOUR CODE HERE
            ##We need to find the distance using Euclicean distance of unknown data from all the points in the dataset
            ##argsort returns the indices that would sort an array.
            ##Sort the collection of indices and distances in ascending order.
            ##We need to get first k values with respect to Y values
            ##As it is a classification problem, we will return the mode of the values
            # euc_dist = []
            euc_dist = np.sqrt(np.sum(pow(X-self.trX, 2),axis=1))    ##row of distances   ##math.dist(X,self.trX)

            ##sorted_eucDistance = euc_dist.sort()            ##sort the distances in increasing order so that we get k closet distance
            dist_indices = np.argsort(euc_dist)               ##indices of the distances in ascending order
            #print(euc_dist)
            #print(dist_indices)
            #print(self.trY)
            kValues = []
            #kValues =  self.trY[dist_indices <= K] 
            count = 0
            for i in dist_indices:
                if count != K:
                    kValues = np.append(kValues,self.trY[i])
                    count = count + 1
                else:
                    break
            val = sum(kValues)                         ##mode/sum of the values
            #util.raiseNotDefined()

            return val
        else:
            # this is an epsilon ball model
            eps = self.opts['eps']     # how big is our epsilon ball

            val = 0                    # this is our return value: #pos - #neg within and epsilon ball of X
            ### TODO: YOUR CODE HERE
            ##We need to find the distance using Euclidean distance of unknown data from all the points in the dataset
            ##We need to find all the points which lies within the region of epsilon ball
            ##As it is a classification problem, we will return the mode of the values
            ##euc_distan = 0
            euc_distan = np.sqrt(np.sum(pow(X-self.trX, 2),axis=1))  ##math.dist(X,self.trX)  ##row of distances

            ##sorted_eucDist = euc_distan.sort()              ##sort the distances in increasing order so that we get k closet distance
            dist_indice = np.argsort(euc_distan)              ##indices of the distances in ascending order

            kValue = []
            ## if euc_distan <= eps then we add that respective Y value in kValue array
            #kValue = self.trY[euc_distan <= eps]
           
            for i in range(len(euc_distan)):
                if euc_distan[i] <= eps:
                    kValue = np.append(kValue,self.trY[i])
                    i = i + 1
            val = sum(kValue)                           ##mode/sum of the values
            #util.raiseNotDefined()
            return val
                
            


    def getRepresentation(self):
        """
        Return the weights
        """
        return (self.trX, self.trY)

    def train(self, X, Y):
        """
        Just store the data.
        """
        self.trX = X
        self.trY = Y
        
