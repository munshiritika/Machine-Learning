##Name: Ritika Munshi
##UID: 118345048
"""
In dumbClassifiers.py, we implement the world's simplest classifiers:
  1) Always predict +1
  2) Always predict the most frequent label from the training data
  3) Just use the sign of the first feature to decide on label
"""
##from imports import *
from binary import *
from numpy  import *
from pylab import *
from runClassifier import *

import util

class AlwaysPredictOne(BinaryClassifier):
    """
    This defines the classifier that always predicts +1.
    """

    def __init__(self, opts):
        """
        do nothing
        """

    def online(self):
        return False

    def __repr__(self):
        return "AlwaysPredictOne"

    def predict(self, X):
        return 1       # return our constant prediction

    def train(self, X, Y):
        """
        do nothing
        """


class AlwaysPredictMostFrequent(BinaryClassifier):
    """
    This defines the classifier that always predicts the
    most frequent label from the training data.
    """

    def __init__(self, opts):
        """
        if we haven't been trained, assume most frequent class is +1
        """
        self.mostFrequentClass = 1

    def online(self):
        return False

    def __repr__(self):
        return "AlwaysPredictMostFrequent(%d)" % self.mostFrequentClass

    def predict(self, X):
        """
        X is an vector and we want to make a single prediction: Just
        return the most frequent class!
        """
        ### TODO: YOUR CODE HERE
        ## util.raiseNotDefined()
        return self.mostFrequentClass  ##we know that self.mostFrequentClass would give us the most frequent class       

    def train(self, X, Y):
        '''
        just figure out what the most frequent class is and store it in self.mostFrequentClass
        '''
        ##Upon receiving training data, it will simply remember whether +1 is more common or -1 is more common. 
        ##It will then always predict this label for future data.
        ##Our self.mostFrequentClass = 1 or self.mostFrequentClass= -1 as our result based on which is more common.
        ### TODO: YOUR CODE HERE
        ## util.raiseNotDefined()
        countpos1 = 0                       ##initialize countpos1, it keeps the track of number of +1 we have in Y
        countneg1 = 0                       ##initialize countneg1, it keeps the track of number of -1 we have in Y
     
        for i in Y:                         ##for every value in Y, and we know that Y either has 1 or -1
            if i == 1:                      ##if i is 1 then we add the count to countpos1
                countpos1 = countpos1 + 1
            else:                           ##if i is -1 then we add the count to countneg1
                countneg1 = countneg1 + 1
        
        if countpos1 > countneg1:           ##if we have more +1 then most frequent would be 1
            self.mostFrequentClass = 1
        else:                               ##if we have more -1 then most frequent would be -1
            self.mostFrequentClass = -1
        

class FirstFeatureClassifier(BinaryClassifier):
    """
    This defines the classifier that always predicts on the basis of
    the first feature only.  In particular, we maintain two
    predictors: one for when the first feature is >0, one for when the
    first feature is <= 0.
    """

    def __init__(self, opts):
        """
        if we haven't been trained, always return 1
        """
        self.classForPos = 1    # what class should we return if X[0] >  0
        self.classForNeg = 1    # what class should we return if X[0] <= 0

    def online(self):
        return False

    def __repr__(self):
        return "FirstFeatureClassifier(%d,%d)" % (self.classForPos, self.classForNeg)

    def predict(self, X):
        """
        check the first feature and make a classification decision based on it
        """

        ### TODO: YOUR CODE HERE
        ## util.raiseNotDefined()
        ##First Feature would be X[0]
        if X[0] <= 0:               ##If first feature is <= 0 --> Negative
            return self.classForNeg  
        else:                       ##If first feature is > 0 --> Positive
            return self.classForPos

    def train(self, X, Y):
        '''
        just figure out what the most frequent class is for each value of X[:,0] and store it
        '''
        ##Based on the training data, it figures out what is the most common value for Y for this group class for the case when X[0] > 0 
        ##and the most common class for the case when X[0] <= 0
        ### TODO: YOUR CODE HERE
        countpos1 = 0
        countneg1 = 0
        countp = 0
        countn = 0
        LessX = np.where(X[:,0] <= 0)
        valLessY = Y[LessX]
        GreaterX = np.where(X[:,0] > 0)
        valGreaterY = Y[GreaterX]

        for i in valLessY:
            if i == 1:                     
                countpos1 = countpos1 + 1
            else:                          
                countneg1 = countneg1 + 1
        
        if countpos1 > countneg1:         
            self.classForNeg = 1
        else:                              
            self.classForNeg = -1

        for i in valGreaterY:
            if i == 1:                     
                countp = countp + 1
            else:                         
                countn = countn + 1
        
        if countp < countn:          
            self.classForPos = -1
        else:                              
            self.classForPos = 1

       ## util.raiseNotDefined()
