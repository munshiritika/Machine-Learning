##Name: Ritika Munshi
##UID: 118345048
"""
In dt.py, you will implement a basic decision tree classifier for
binary classification.  Your implementation should be based on the
minimum classification error heuristic (even though this isn't ideal,
it's easier to code than the information-based metrics).
"""

##from numpy import *

import numpy as np

from binary import *
import util

class DT(BinaryClassifier):
    """
    This class defines the decision tree implementation.  It comes
    with a partial implementation for the tree data structure that
    will enable us to print the tree in a canonical form.
    """

    def __init__(self, opts):
        """
        Initialize our internal state.  The options are:
          opts.maxDepth = maximum number of features to split on
                          (i.e., if maxDepth == 1, then we're a stump)
        """

        self.opts = opts

        # initialize the tree data structure.  all tree nodes have a
        # "isLeaf" field that is true for leaves and false otherwise.
        # leaves have an assigned class (+1 or -1).  internal nodes
        # have a feature to split on, a left child (for when the
        # feature value is < 0.5) and a right child (for when the
        # feature value is >= 0.5)
        
        self.isLeaf = True
        self.label  = 1

    def online(self):
        """
        Our decision trees are batch
        """
        return False

    def __repr__(self):
        """
        Return a string representation of the tree
        """
        return self.displayTree(0)

    def displayTree(self, depth):
        # recursively display a tree
        if self.isLeaf:
            return (" " * (depth*2)) + "Leaf " + repr(self.label) + "\n"
        else:
            return (" " * (depth*2)) + "Branch " + repr(self.feature) + "\n" + \
                      self.left.displayTree(depth+1) + \
                      self.right.displayTree(depth+1)

    def predict(self, X):
        """
        Traverse the tree to make predictions.  You should threshold X
        at 0.5, so <0.5 means left branch and >=0.5 means right
        branch.
        """

        ### TODO: YOUR CODE HERE
        if self.isLeaf == False:         ##If that node is not a Leaf
            d1 = self.feature            ##store the index of features in d1
            if X[d1] < 0.5:              ##If X[d1] which means X of that feature index is < 0.5 threshold ##one dimen
                return self.left.predict(X)     ##then we traverse over the left portion of the tree
            else:                        ##ekse
                return self.right.predict(X)    ##we traverse over the right portion of the tree
        else:                            ##else if that node is a Leaf
            return self.label            ##Return the label meaning the value it is holding in that Leaf Node
        ##util.raiseNotDefined()

    def trainDT(self, X, Y, maxDepth, used):
        """
        recursively build the decision tree
        """

        # get the size of the data set
        N,D = X.shape

        # check to see if we're either out of depth or no longer
        # have any decisions to make
        if maxDepth <= 0 or len(util.uniq(Y)) <= 1:
            # we'd better end at this point.  need to figure
            # out the label to return
            ### TODO: YOUR CODE HERE
            self.isLeaf = True          ##If maxDepth <= 0 denotes that the node is leaf so we update it is to true
            ##util.raiseNotDefined()    
            ### TODO: YOUR CODE HERE
            self.label  = util.mode(Y)  ##Return the label of Y associated by using the util class and the function mode which return the most common value in Y
            ##util.raiseNotDefined()    


        else:
            # we need to find a feature to split on
            bestFeature = -1     # which feature has lowest error
            bestError   = N      # the number of errors for this feature
            for d in range(D):
                # have we used this feature yet
                if d in used:
                    continue

                # suppose we split on this feature; what labels
                # would go left and right?
                LessX = np.where(X[:,d] < 0.5)      #get the index of the X values with < 0.5
                valLessY = Y[LessX]                 #get the respective assocaited Y values
                GreaterX = np.where(X[:,d] >= 0.5)  #get the index of the X values with >= 0
                valGreaterY = Y[GreaterX]           #get the respective assocaited Y values

                ### TODO: YOUR CODE HERE
                leftY  = valLessY                   #update the leftY which would be the left portion of the tree based on the threshold
                ##util.raiseNotDefined()  
                ### TODO: YOUR CODE HERE 
                rightY = valGreaterY                #update the rightY which would be the riight portion of the tree based on the threshold
                ##util.raiseNotDefined()


                # we'll classify the left points as their most
                # common class and ditto right points.  our error
                # is the how many are not their mode.
                countpos1 = 0                       #initialization
                countneg1 = 0                       #initialization
                countposs1 = 0                      #initialization
                countnegg1 = 0                      #initialization
                errorL = 0                          #initialization
                errorR = 0                          #initialization

                for i in valLessY:                  #traverse over the array which holds the value for < 0.5 threshold
                    if i == 1:                      #if i is 1 then we add the count to countpos1
                       countpos1 = countpos1 + 1
                    else:                           #if i is -1 then we add the count to countneg1
                       countneg1 = countneg1 + 1

                if countpos1 > countneg1:           #if we have more positive values than negative values
                    errorL = countneg1              #update the errorL with the negative count because we go over the opposite one
                else:
                    errorL = countpos1              #else we update the errorL with the positive count

                for i in valGreaterY:               #traverse over the array which holds the value for >= 0.5 threshold
                    if i == 1:                      #if i is 1 then we add the count to countpos1
                       countposs1 = countposs1 + 1
                    else:                           #if i is -1 then we add the count to countneg1
                       countnegg1 = countnegg1 + 1

                if countpos1 > countneg1:           #if we have more positive values than negative values
                    errorR = countposs1             #update the errorR with the positive count
                else:
                    errorR = countnegg1             #else #update the errorR with the negative count
                    
                ### TODO: YOUR CODE HERE
                error = errorL + errorR             #error would be sum of the error from left and error from right portion of the tree
                ##util.raiseNotDefined()    


                # check to see if this is a better error rate
                if error <= bestError:
                    bestFeature = d
                    bestError   = error

            if bestFeature < 0:
                # this shouldn't happen, but just in case...
                self.isLeaf = True
                self.label  = util.mode(Y)

            else:
                self.isLeaf  = False        ## util.raiseNotDefined()    ### TODO: YOUR CODE HERE
                self.feature = bestFeature  ## util.raiseNotDefined()    ### TODO: YOUR CODE HERE


                self.left  = DT({'maxDepth': maxDepth-1})
                self.right = DT({'maxDepth': maxDepth-1})
                # recurse on our children by calling
                #   self.left.trainDT(...) 
                # and
                #   self.right.trainDT(...) 
                # with appropriate arguments
                ### TODO: YOUR CODE HERE

                indLX = np.where(X[:,bestFeature] < 0.5)
                valLY = Y[indLX]
                valLX = X[indLX]
                indGX = np.where(X[:,bestFeature] >= 0.5)
                valGY = Y[indGX]
                valGX = X[indGX]

                used.append(bestFeature) 

                ##check if X and Y are not empty for recursive call to happen
                if ((np.any(valLX) == True) and (np.any(valLY) == True)):
                    self.left.trainDT(valLX, valLY, self.left.opts['maxDepth'], used)
                if((np.any(valGX) == True) and (np.any(valGY) == True)):
                    self.right.trainDT(valGX, valGY, self.right.opts['maxDepth'], used)
             ##   util.raiseNotDefined()

    def train(self, X, Y):
        """
        Build a decision tree based on the data from X and Y.  X is a
        matrix (N x D) for N many examples on D features.  Y is an
        N-length vector of +1/-1 entries.

        Some hints/suggestions:
          - make sure you don't build the tree deeper than self.opts['maxDepth']
          
          - make sure you don't try to reuse features (this could lead
            to very deep trees that keep splitting on the same feature
            over and over again)
            
          - it is very useful to be able to 'split' matrices and vectors:
            if you want the ids for all the Xs for which the 5th feature is
            on, say X(:,5)>=0.5.  If you want the corresponting classes,
            say Y(X(:,5)>=0.5) and if you want the correspnding rows of X,
            say X(X(:,5)>=0.5,:)
            
          - i suggest having train() just call a second function that
            takes additional arguments telling us how much more depth we
            have left and what features we've used already

          - take a look at the 'mode' and 'uniq' functions in util.py
        """

        self.trainDT(X, Y, self.opts['maxDepth'], [])


    def getRepresentation(self):
        """
        Return our internal representation: for DTs, this is just our
        tree structure -- i.e., ourselves
        """
        
        return self

